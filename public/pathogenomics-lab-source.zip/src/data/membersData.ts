import { TeamMember, ScholarAlumni } from '../types';

export const researchTeam: TeamMember[] = [
  {
    id: "mem-1",
    name: "Dr. Anamika Mishra",
    designation: "Principal Scientist at ICAR-NIHSAD",
    group: "research",
    photo: "/images/members/default.jpg",
    description: "Senior molecular biologist focused on animal viral genomics, host response dynamics, and diagnostic biomarker validation across high-containment avian and mammalian models.",
    email: "anamika.mishra@icar.gov.in"
  },
  {
    id: "mem-2",
    name: "Dr. Piyus Joshi",
    designation: "Project Research Scientist-III",
    group: "research",
    photo: "/images/members/default.jpg",
    description: "Investigating pan-viral pathogen discovery pipelines, viral metaviromics, and high-throughput sequencing datasets under the National One Health Mission surveillance network.",
    email: "piyus.joshi@nihsad.res.in"
  },
  {
    id: "mem-3",
    name: "Dr. Shailendar Mishra",
    designation: "Project Research Scientist-II",
    group: "research",
    photo: "/images/members/default.jpg",
    description: "Specialized in serological and molecular diagnostic development for high-risk zoonotic viruses, focusing on multiplex assays for priority pathogen surveillance.",
    email: "shailendar.mishra@nihsad.res.in"
  },
  {
    id: "mem-4",
    name: "Dr. Debabrata Dandsena",
    designation: "Project Research Scientist-II",
    group: "research",
    photo: "/images/members/default.jpg",
    description: "Focusing on viral pathogenesis, animal model evaluations, and biosafety management within BSL-3 and ABSL-3 containment infrastructure.",
    email: "debabrata.d@nihsad.res.in"
  },
  {
    id: "mem-5",
    name: "Dr. Sonal Sharma",
    designation: "Research Scholar (PhD)",
    group: "research",
    photo: "/images/members/default.jpg",
    description: "Doctoral research centered on metabolomic and transcriptomic profiling of avian influenza virus infections and host-pathogen interplay.",
    email: "sonal.sharma@nihsad.res.in"
  },
  {
    id: "mem-6",
    name: "Varsha Rani Agrawal",
    designation: "MVSc Scholar, Veterinary Public Health",
    group: "research",
    photo: "/images/members/default.jpg",
    description: "Investigating zoonotic spillover risks at the animal-human interface with emphasis on avian and rodent-associated pathogen surveillance.",
    email: "varsha.agrawal@nihsad.res.in"
  },
  {
    id: "mem-7",
    name: "Vedansh Trivedi",
    designation: "Research Scholar (PhD)",
    group: "research",
    photo: "/images/members/default.jpg",
    description: "Doctoral research exploring biomarker discovery, gene expression regulation, and non-coding RNA pathways during emerging viral infections.",
    email: "vedansh.trivedi@nihsad.res.in"
  },
  {
    id: "mem-8",
    name: "Deepak",
    designation: "Project Fellow",
    group: "research",
    photo: "/images/members/default.jpg",
    description: "Supporting laboratory sample processing, high-throughput nucleic acid extraction, and real-time RT-PCR diagnostic workflows.",
    email: "deepak.fellow@nihsad.res.in"
  },
  {
    id: "mem-9",
    name: "Prince Kumar",
    designation: "ILRI Consultant for MERS Vaccine",
    group: "research",
    photo: "/images/members/default.jpg",
    description: "Leading collaborative vaccine evaluation and sero-surveillance protocols under the joint ICAR-NIHSAD and CGIAR-ILRI international program.",
    email: "prince.kumar@cgiar.org"
  },
  {
    id: "mem-10",
    name: "Himanshu",
    designation: "Project Research Scientist-I (MMSA Project)",
    group: "research",
    photo: "/images/members/default.jpg",
    description: "Dedicated to the development and clinical validation of novel multiplex serological assay platforms for national pandemic preparedness.",
    email: "himanshu.mmsa@nihsad.res.in"
  },
  {
    id: "mem-11",
    name: "Muskan",
    designation: "Project Fellow",
    group: "research",
    photo: "/images/members/default.jpg",
    description: "Assisting with high-containment biosafety procedures, field sample accessioning, and metagenomic sequencing library preparation.",
    email: "muskan.fellow@nihsad.res.in"
  },
  {
    id: "mem-12",
    name: "Dr. Arti Chaurasiya",
    designation: "Project Fellow",
    group: "research",
    photo: "/images/members/default.jpg",
    description: "Contributing to molecular diagnostics, antibody characterization, and in vitro neutralization assays against emerging animal viruses.",
    email: "arti.chaurasiya@nihsad.res.in"
  },
  {
    id: "mem-13",
    name: "Dr. Piyush Soni",
    designation: "Project Fellow",
    group: "research",
    photo: "/images/members/default.jpg",
    description: "Conducting bioinformatics analyses, sequence assembly, and phylogenetic tracking of viral isolates from nationwide surveillance networks.",
    email: "piyush.soni@nihsad.res.in"
  }
];

export const technicalStaff: TeamMember[] = [
  {
    id: "tech-1",
    name: "Surendar",
    designation: "Technical Officer",
    group: "technical",
    photo: "/images/members/default.jpg",
    description: "High-containment BSL-3 laboratory engineering operations, air-handling filtration maintenance, and biocontainment protocol oversight."
  },
  {
    id: "tech-2",
    name: "Bharat",
    designation: "Senior Technical Assistant",
    group: "technical",
    photo: "/images/members/default.jpg",
    description: "Animal BSL-3 containment facility husbandry, containment airlocks, and experimental animal protocol support."
  },
  {
    id: "tech-3",
    name: "Ankit",
    designation: "Technical Assistant",
    group: "technical",
    photo: "/images/members/default.jpg",
    description: "Specific Pathogen Free (SPF) unit operation, barrier cleanliness maintenance, and microbiological monitoring."
  },
  {
    id: "tech-4",
    name: "Bharat [Field & Containment Ops]",
    designation: "Technical Assistant",
    group: "technical",
    photo: "/images/members/default.jpg",
    description: "Laboratory biosafety equipment calibration, autoclave sterilization systems, and bio-waste decontamination protocols."
  },
  {
    id: "tech-5",
    name: "Jagdish",
    designation: "Laboratory Attendant",
    group: "technical",
    photo: "/images/members/default.jpg",
    description: "Sample reception, cold-chain repository management, and day-to-day diagnostic media preparation."
  },
  {
    id: "tech-6",
    name: "Aran",
    designation: "Animal House Assistant",
    group: "technical",
    photo: "/images/members/default.jpg",
    description: "Large animal containment isolation suite maintenance, pig and cattle welfare, and containment sanitation."
  }
];

export const alumniScholars: ScholarAlumni[] = [
  {
    id: 1,
    name: "Rupam Dutta",
    institution: "IVRI, Izatnagar",
    title: "Identification of the Dynamics of Viral Metagenome between Native and Migratory Duck and Goose in North-Eastern Region of India",
    degree: "PhD",
    year: 2017,
    supervisionType: "supervised"
  },
  {
    id: 2,
    name: "Chandan K",
    institution: "IVRI, Izatnagar",
    title: "Development of Multiplex Nucleic Acid Lateral Flow Assay for Hemagglutinin (HA) subtyping of Avian Influenza Virus",
    degree: "MVSc",
    year: 2017,
    supervisionType: "supervised"
  },
  {
    id: 3,
    name: "Mohammed Fawaz",
    institution: "IVRI, Izatnagar",
    title: "Metagenomic profiling of gut virome of domestic ducks",
    degree: "MVSc",
    year: 2014,
    supervisionType: "supervised"
  },
  {
    id: 4,
    name: "Aman Kamboj",
    institution: "IVRI, Izatnagar",
    title: "Evaluation of real time RT-PCR for detection of CCHF virus",
    degree: "MVSc",
    year: 2012,
    supervisionType: "supervised"
  },
  {
    id: 5,
    name: "Ravi Prakash",
    institution: "IVRI, Izatnagar",
    title: "Construction of artificial miRNA polycistron encoding multiple anti-avian influenza virus siRNAs",
    degree: "MVSc",
    year: 2010,
    supervisionType: "supervised"
  },
  {
    id: 6,
    name: "Basavaraj Sajjanar",
    institution: "IVRI, Izatnagar",
    title: "Identification of small interfering RNAs for silencing of Infectious Bursal Disease Virus infection",
    degree: "MVSc",
    year: 2008,
    supervisionType: "supervised"
  },
  {
    id: 7,
    name: "Sachin Samuchiwal",
    institution: "GJUST, Hisar",
    title: "Identification and screening of stem cell markers in umbilical cord blood of buffalo",
    degree: "MSc",
    year: 2008,
    supervisionType: "supervised"
  },
  {
    id: 8,
    name: "Sandeep Kumar",
    institution: "GJUST, Hisar",
    title: "Molecular characterization of exon-8 of ovine DGAT-1 gene",
    degree: "MSc",
    year: 2007,
    supervisionType: "supervised"
  },
  {
    id: 9,
    name: "Anil Kumar",
    institution: "GJUST, Hisar",
    title: "Molecular characterization of major candidate genes associated with milk fat percentage in Indian buffalo",
    degree: "PhD",
    year: 2006,
    supervisionType: "supervised"
  },
  {
    id: 10,
    name: "Santhalembi Chingtham",
    institution: "IVRI, Izatnagar",
    title: "Development of Multiplex Diagnostic Assay for Nipah Virus, Reston Ebolavirus, and Middle East Respiratory Syndrome Coronavirus infections in Bats",
    degree: "PhD",
    year: 2018,
    supervisionType: "co-supervised"
  },
  {
    id: 11,
    name: "P Vijaykumar",
    institution: "IVRI, Izatnagar",
    title: "Lung proteome analysis of Highly pathogenic avian influenza virus H5N1 infection progression in chicken and duck",
    degree: "PhD",
    year: 2016,
    supervisionType: "co-supervised"
  },
  {
    id: 12,
    name: "Pradeep Ranaware",
    institution: "IVRI, Izatnagar",
    title: "Experimental transmission of highly pathogenic duck isolate of H5N1 and host gene expression",
    degree: "PhD",
    year: 2014,
    supervisionType: "co-supervised"
  }
];
