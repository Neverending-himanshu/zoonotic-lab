import React, { useState } from 'react';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { PlaceholderFrame } from '../components/PlaceholderFrame';
import { researchTeam, technicalStaff, alumniScholars } from '../data/membersData';
import { Users, GraduationCap, Wrench, Mail, BookOpen } from 'lucide-react';

interface MembersPageProps {
  initialSubTab?: 'current' | 'alumni';
  onNavigate: (route: string) => void;
}

export const MembersPage: React.FC<MembersPageProps> = ({
  initialSubTab = 'current',
  onNavigate
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'current' | 'alumni'>(initialSubTab);

  return (
    <div className="space-y-8 pb-16">
      <Breadcrumbs
        items={[
          { label: 'Lab Members' },
          { label: activeSubTab === 'current' ? 'Current Team' : 'Alumni Scholars' }
        ]}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Header & Sub-navigation */}
        <div className="border-b border-slate-200 pb-4 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-emerald-800">
              Laboratory Personnel
            </span>
            <h1 className="font-serif text-3xl font-bold text-slate-900 mt-1">
              Research Team, Technical Staff &amp; Alumni
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 mt-1">
              Scientists, doctoral fellows, technical specialists, and graduated postgraduate scholars.
            </p>
          </div>

          <div className="flex border border-slate-300 rounded p-1 bg-slate-50 text-xs">
            <button
              onClick={() => setActiveSubTab('current')}
              className={`px-3 py-1.5 rounded font-medium transition-colors cursor-pointer ${
                activeSubTab === 'current'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Current Team ({researchTeam.length + technicalStaff.length})
            </button>
            <button
              onClick={() => setActiveSubTab('alumni')}
              className={`px-3 py-1.5 rounded font-medium transition-colors cursor-pointer ${
                activeSubTab === 'alumni'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Alumni Scholars ({alumniScholars.length})
            </button>
          </div>
        </div>

        {/* 1. CURRENT TEAM */}
        {activeSubTab === 'current' && (
          <div className="space-y-12">
            {/* Research Team Grid: 4 per row as strictly requested in A5 & B7 */}
            <section className="space-y-4">
              <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
                <Users className="w-5 h-5 text-teal-800" />
                <h2 className="font-serif text-xl font-bold text-slate-900">
                  Research Team ({researchTeam.length})
                </h2>
              </div>
              <p className="text-xs text-slate-500">
                Principal scientists, project research scientists, doctoral researchers, and project fellows.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 pt-2">
                {researchTeam.map((member) => (
                  <div
                    key={member.id}
                    className="bg-white border border-slate-200 rounded overflow-hidden shadow-2xs hover:border-slate-300 transition-colors flex flex-col"
                  >
                    {/* Neutral placeholder photo (1:1 ratio per B10) */}
                    <div className="p-4 bg-slate-50/60 pb-0">
                      <PlaceholderFrame
                        src={member.photo}
                        alt={member.name}
                        ratio="1:1"
                        caption="Team Member Photo"
                        className="rounded-xs max-w-[200px] mx-auto"
                      />
                    </div>

                    {/* Member details: Name, designation, 3-line description */}
                    <div className="p-4 space-y-2 flex-1 flex flex-col justify-between">
                      <div className="space-y-1">
                        <h3 className="font-serif font-bold text-sm sm:text-base text-slate-900 leading-snug">
                          {member.name}
                        </h3>
                        <div className="text-xs font-medium text-teal-800">
                          {member.designation}
                        </div>
                        {/* 3-line description kept in editable data file per A5 */}
                        <p className="text-xs text-slate-600 leading-relaxed pt-1 line-clamp-3">
                          {member.description}
                        </p>
                      </div>

                      {member.email && (
                        <div className="pt-2 border-t border-slate-100 text-[11px] text-slate-400 truncate flex items-center gap-1">
                          <Mail className="w-3 h-3 text-slate-400 shrink-0" />
                          <span className="truncate">{member.email}</span>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* Technical Staff Grid */}
            <section className="space-y-4 pt-4 border-t border-slate-200">
              <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
                <Wrench className="w-5 h-5 text-slate-700" />
                <h2 className="font-serif text-xl font-bold text-slate-900">
                  Technical Staff ({technicalStaff.length})
                </h2>
              </div>
              <p className="text-xs text-slate-500">
                Specialized biocontainment technical officers, animal husbandry operators, and laboratory assistants.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-6 pt-2">
                {technicalStaff.map((staff) => (
                  <div
                    key={staff.id}
                    className="bg-white border border-slate-200 rounded p-5 shadow-2xs space-y-3"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 shrink-0">
                        <PlaceholderFrame
                          src={staff.photo}
                          alt={staff.name}
                          ratio="1:1"
                          caption=""
                          className="rounded-full overflow-hidden"
                        />
                      </div>
                      <div>
                        <h3 className="font-serif font-bold text-sm text-slate-900">
                          {staff.name}
                        </h3>
                        <div className="text-xs text-slate-500">
                          {staff.designation}
                        </div>
                      </div>
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed line-clamp-3">
                      {staff.description}
                    </p>
                  </div>
                ))}
              </div>
            </section>
          </div>
        )}

        {/* 2. ALUMNI SCHOLARS (Supervised & Co-Supervised) */}
        {activeSubTab === 'alumni' && (
          <div className="space-y-8">
            <div className="bg-slate-50 border border-slate-200 rounded p-4 text-xs text-slate-600">
              Postgraduate scholars supervised and co-supervised by Dr. Ashwin Ashok Raut across IVRI Izatnagar and GJUST Hisar. Co-supervised scholars are explicitly designated.
            </div>

            <div className="divide-y divide-slate-200 border border-slate-200 rounded bg-white overflow-hidden shadow-2xs">
              {alumniScholars.map((alum) => {
                const isCoSupervised = alum.supervisionType === 'co-supervised';

                return (
                  <div key={alum.id} className="p-5 hover:bg-slate-50/80 transition-colors space-y-2">
                    <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1 text-xs">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-slate-500 font-semibold">
                          #{alum.id}
                        </span>
                        <h3 className="font-serif font-bold text-base text-slate-900">
                          {alum.name}
                        </h3>
                        <span className="text-xs text-slate-500">
                          ({alum.institution})
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="font-mono text-[11px] font-semibold text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                          {alum.degree} · {alum.year}
                        </span>
                        {isCoSupervised ? (
                          <span className="text-[10px] font-bold uppercase tracking-wider text-amber-900 bg-amber-50 px-2 py-0.5 rounded border border-amber-300">
                            Co-Supervised
                          </span>
                        ) : (
                          <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                            Supervised
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="text-xs sm:text-sm text-slate-700 bg-slate-50/80 p-3 rounded border border-slate-200/80">
                      <span className="font-semibold text-slate-900">Dissertation: </span>
                      <span className="italic font-serif">"{alum.title}"</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
